export enum AnimationName {
  INTRO = "intro",
  OUTRO_WIN = "outro-win",
  OUTRO_DEFEAT = "outro-defeat",
}
