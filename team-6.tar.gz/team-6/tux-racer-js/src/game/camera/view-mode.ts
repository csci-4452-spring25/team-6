export enum ViewMode {
  ABOVE = 1,
  FOLLOWING,
}
