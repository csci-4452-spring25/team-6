export enum CharacterName {
  TUX = "tux",
}
