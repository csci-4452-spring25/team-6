export enum GameState {
  INTRO = 1,
  RACING,
  BREAKING,
  OUTRO,
  TERMINATED,
}
