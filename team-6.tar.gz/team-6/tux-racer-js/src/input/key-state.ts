export type KeyState = {
  keyboardA: boolean;
  keyboardD: boolean;
  keyboardW: boolean;
  keyboardS: boolean;

  keyboardArrowLeft: boolean;
  keyboardArrowRight: boolean;
  keyboardArrowUp: boolean;
  keyboardArrowDown: boolean;
};
