export type TouchState = {
  stickAngle: number | undefined;
  isPointingForward: boolean;
  isPointingBackward: boolean;
};
