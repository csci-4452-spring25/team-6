export enum Axis {
  X = 1,
  Y,
  Z,
}
