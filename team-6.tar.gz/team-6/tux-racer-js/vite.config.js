export default {
  base: "./",
  build: {
    target: "esnext",
  },
};
